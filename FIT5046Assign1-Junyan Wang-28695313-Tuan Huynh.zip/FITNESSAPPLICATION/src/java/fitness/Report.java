/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitness;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author andrew
 */
@Entity
@Table(name = "REPORT")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Report.findAll", query = "SELECT r FROM Report r")
    , @NamedQuery(name = "Report.findByUsernameANDGoal2", query = "SELECT r FROM Report r WHERE r.userid.username = :username AND r.goal = :goal")
    , @NamedQuery(name = "Report.findByReportid", query = "SELECT r FROM Report r WHERE r.reportid = :reportid")
    , @NamedQuery(name = "Report.findByCreatedate", query = "SELECT r FROM Report r WHERE r.createdate = :createdate")
    , @NamedQuery(name = "Report.findByTotalConsume", query = "SELECT r FROM Report r WHERE r.totalConsume = :totalConsume")
    , @NamedQuery(name = "Report.findByTotalBurned", query = "SELECT r FROM Report r WHERE r.totalBurned = :totalBurned")
    , @NamedQuery(name = "Report.findByTotalSteps", query = "SELECT r FROM Report r WHERE r.totalSteps = :totalSteps")
    , @NamedQuery(name = "Report.findByGoal", query = "SELECT r FROM Report r WHERE r.goal = :goal")})
public class Report implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "REPORTID")
    private Integer reportid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "CREATEDATE")
    private String createdate;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "TOTAL_CONSUME")
    private String totalConsume;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "TOTAL_BURNED")
    private String totalBurned;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "TOTAL_STEPS")
    private String totalSteps;
    @Basic(optional = false)
    @NotNull
    @Column(name = "GOAL")
    private int goal;
    @JoinColumn(name = "USERID", referencedColumnName = "USERID")
    @ManyToOne(optional = false)
    private Users userid;

    public Report() {
    }

    public Report(Integer reportid) {
        this.reportid = reportid;
    }

    public Report(Integer reportid, String createdate, String totalConsume, String totalBurned, String totalSteps, int goal) {
        this.reportid = reportid;
        this.createdate = createdate;
        this.totalConsume = totalConsume;
        this.totalBurned = totalBurned;
        this.totalSteps = totalSteps;
        this.goal = goal;
    }

    public Integer getReportid() {
        return reportid;
    }

    public void setReportid(Integer reportid) {
        this.reportid = reportid;
    }

    public String getCreatedate() {
        return createdate;
    }

    public void setCreatedate(String createdate) {
        this.createdate = createdate;
    }

    public String getTotalConsume() {
        return totalConsume;
    }

    public void setTotalConsume(String totalConsume) {
        this.totalConsume = totalConsume;
    }

    public String getTotalBurned() {
        return totalBurned;
    }

    public void setTotalBurned(String totalBurned) {
        this.totalBurned = totalBurned;
    }

    public String getTotalSteps() {
        return totalSteps;
    }

    public void setTotalSteps(String totalSteps) {
        this.totalSteps = totalSteps;
    }

    public int getGoal() {
        return goal;
    }

    public void setGoal(int goal) {
        this.goal = goal;
    }

    public Users getUserid() {
        return userid;
    }

    public void setUserid(Users userid) {
        this.userid = userid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (reportid != null ? reportid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Report)) {
            return false;
        }
        Report other = (Report) object;
        if ((this.reportid == null && other.reportid != null) || (this.reportid != null && !this.reportid.equals(other.reportid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "fitness.Report[ reportid=" + reportid + " ]";
    }
    
}
