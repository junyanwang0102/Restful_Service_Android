/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitness.service;

import fitness.Users;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author andrew
 */
@Stateless
@Path("fitness.users")
public class UsersFacadeREST extends AbstractFacade<Users> {

    @PersistenceContext(unitName = "FITNESSAPPLICATIONPU")
    private EntityManager em;

    public UsersFacadeREST() {
        super(Users.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Users entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Users entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }
    
    // b2
    @GET
    @Path("findByNameANDCode/{username}/{postcode}")
    @Produces({"application/json"})
    public List<Users> findByNameANDCode(@PathParam("username") String username, @PathParam("postcode") String postcode) {
        TypedQuery<Users> query = em.createQuery("SELECT s FROM Users s WHERE s.username = :username AND s.postcode=:postcode", Users.class);
        query.setParameter("username", username);
        query.setParameter("postcode", postcode);
        return query.getResultList();
    }
    
    // 4a
    @GET
    @Path("calculateCaloriesperStep/{userid}")
    @Produces({"text/plain"})
    public double calculateCaloriesperStep(@PathParam("userid") int userid) {
        TypedQuery<Users> query = em.createQuery("SELECT s FROM Users s WHERE s.userid = :userid", Users.class);
        query.setParameter("userid", userid);
        List<Users> list = query.getResultList( );
        double stepcalorie = 0.0;
        if (list != null && list.size() > 0 && list.get(0) != null) {
            Users u = new Users();
            u = list.get(0);
            String userweight = u.getWeight();
            double caloriepermile = Double.valueOf(userweight) * 0.49;
            double milepersteps = u.getMilesteps();
            stepcalorie = caloriepermile / milepersteps;  
        }
        return stepcalorie;
    }
    
    // 4b
    @GET
    @Path("calculateBMR/{userid}")
    @Produces({"text/plain"})
    public double calculateBMR(@PathParam("userid") int userid) {
        TypedQuery<Users> query = em.createQuery("SELECT s FROM Users s WHERE s.userid = :userid", Users.class);
        query.setParameter("userid", userid);
        List<Users> list1 = query.getResultList( );
        double bmr = 0.0;
        Users u1 = new Users();
        u1 = list1.get(0);
        String userweight = u1.getWeight();
        double doubleweight = Double.valueOf(userweight);
        String userheight = u1.getHeight();
        double doubleheight = Double.valueOf(userheight);
        String userdob = u1.getDob().substring(0, 4);
        double userage = 2019 - Double.valueOf(userdob);
        if (list1 != null && list1.size() > 0 && list1.get(0) != null && list1.get(0).getGender().equals("M")) {
            bmr = (13.75 * doubleweight) + (5.003 * doubleheight) - (6.755 * userage) + 66.5; 
        } else if (list1 != null && list1.size() > 0 && list1.get(0) != null && list1.get(0).getGender().equals("F")){
            bmr = (9.563 * doubleweight) + (1.85 * doubleheight) - (4.676 * userage) + 655.1;  
        } else{
            System.out.println("A user must be male or female");
        }
        return bmr;
    }
    
    // 4c
    @GET
    @Path("calculateTotalCalorie/{userid}")
    @Produces({"text/plain"})
    public double calculateTotalCalorie(@PathParam("userid") int userid) {
        TypedQuery<Users> query = em.createQuery("SELECT s FROM Users s WHERE s.userid = :userid", Users.class);
        query.setParameter("userid", userid);
        List<Users> list2 = query.getResultList( );
        double bmr = 0.0;
        bmr = calculateBMR(userid);
        double totalCalorie = 0.0;
        if (list2 != null && list2.size() > 0 && list2.get(0) != null && list2.get(0).getActivitylevel() == 1) {
            totalCalorie = bmr * 1.2;
        } else if (list2 != null && list2.size() > 0 && list2.get(0) != null && list2.get(0).getActivitylevel() == 2){
            totalCalorie = bmr * 1.375; 
        } else if (list2 != null && list2.size() > 0 && list2.get(0) != null && list2.get(0).getActivitylevel() == 3){
            totalCalorie = bmr * 1.55; 
        } else if (list2 != null && list2.size() > 0 && list2.get(0) != null && list2.get(0).getActivitylevel() == 4) {
            totalCalorie = bmr * 1.725; 
        } else if (list2 != null && list2.size() > 0 && list2.get(0) != null && list2.get(0).getActivitylevel() == 5) {
            totalCalorie = bmr * 1.9; 
        }
        return totalCalorie;
    }
    
  

    
    
    

    
    
    
    // add in UsersFacade
    @GET
    @Path("findByUsername/{username}")
        @Produces({"application/json"})
        public List<Users> findByUsername (@PathParam("username") String username){
            Query query = em.createNamedQuery("Users.findByUsername");
            query.setParameter("username", username);
            return query.getResultList();
        }
    
    @GET
    @Path("findBySurname/{surname}")
        @Produces({"application/json"})
        public List<Users> findBySurname (@PathParam("surname") String surname){
            Query query = em.createNamedQuery("Users.findBySurname");
            query.setParameter("surname", surname);
            return query.getResultList();
        }
       
    @GET
    @Path("findByEmail/{email}")
        @Produces({"application/json"})
        public List<Users> findByEmail (@PathParam("email") String email){
            Query query = em.createNamedQuery("Users.findByEmail");
            query.setParameter("email", email);
            return query.getResultList();
        }
        
    @GET
    @Path("findByDob/{dob}")
        @Produces({"application/json"})
        public List<Users> findByDob (@PathParam("dob") String dob){
            Query query = em.createNamedQuery("Users.findByDob");
            query.setParameter("dob", dob);
            return query.getResultList();
        }
        
    @GET
    @Path("findByHeight/{height}")
        @Produces({"application/json"})
        public List<Users> findByHeight (@PathParam("height") String height){
            Query query = em.createNamedQuery("Users.findByHeight");
            query.setParameter("height", height);
            return query.getResultList();
        }
        
    @GET
    @Path("findByWeight/{weight}")
        @Produces({"application/json"})
        public List<Users> findByWeight (@PathParam("weight") String weight){
            Query query = em.createNamedQuery("Users.findByWeight");
            query.setParameter("weight", weight);
            return query.getResultList();
        }
        
    @GET
    @Path("findByGender/{gender}")
        @Produces({"application/json"})
        public List<Users> findByGender (@PathParam("gender") String gender){
            Query query = em.createNamedQuery("Users.findByGender");
            query.setParameter("gender", gender);
            return query.getResultList();
        }
        
    @GET
    @Path("findByAddress/{address}")
        @Produces({"application/json"})
        public List<Users> findByAddress (@PathParam("address") String address){
            Query query = em.createNamedQuery("Users.findByAddress");
            query.setParameter("address", address);
            return query.getResultList();
        }

    @GET
    @Path("findByPostcode/{postcode}")
        @Produces({"application/json"})
        public List<Users> findByPostcode (@PathParam("postcode") String postcode){
            Query query = em.createNamedQuery("Users.findByPostcode");
            query.setParameter("postcode", postcode);
            return query.getResultList();
        }
            
    @GET
    @Path("findByActivitylevel/{activitylevel}")
        @Produces({"application/json"})
        public List<Users> findByActivitylevel (@PathParam("activitylevel") int activitylevel){
            Query query = em.createNamedQuery("Users.findByActivitylevel");
            query.setParameter("activitylevel", activitylevel);
            return query.getResultList();
        }
        
    @GET
    @Path("findByMilesteps/{milesteps}")
        @Produces({"application/json"})
        public List<Users> findByMilesteps (@PathParam("milesteps") int milesteps){
            Query query = em.createNamedQuery("Users.findByMilesteps");
            query.setParameter("milesteps", milesteps);
            return query.getResultList();
        }
        
        
        
        
    

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Users find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
