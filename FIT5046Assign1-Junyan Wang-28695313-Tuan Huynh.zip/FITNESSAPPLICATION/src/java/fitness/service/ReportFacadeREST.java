/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitness.service;

import fitness.Report;
import java.util.List;
import javax.ejb.Stateless;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author andrew
 */
@Stateless
@Path("fitness.report")
public class ReportFacadeREST extends AbstractFacade<Report> {

    @PersistenceContext(unitName = "FITNESSAPPLICATIONPU")
    private EntityManager em;

    public ReportFacadeREST() {
        super(Report.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Report entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Report entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }
    
    // 3
    
    @GET
    @Path("findByUsernameANDGoal/{username}/{goal}")
    @Produces({"application/json"})
    public List<Report> findByUsernameANDGoal(@PathParam("username") String username,@PathParam("goal") int goal) {
        TypedQuery<Report> query = em.createQuery("SELECT r FROM Report r WHERE r.userid.username = :username AND r.goal = :goal", Report.class);
        query.setParameter("username", username);
        query.setParameter("goal", goal);
        return query.getResultList();
    }
    
    // 4
    
    @GET
    @Path("findByUsernameANDGoal2/{username}/{goal}")
    @Produces({"application/json"})
    public List<Report> findByUsernameANDGoal2(@PathParam("username") String username, @PathParam("goal") int goal) {
        Query query = em.createNamedQuery("Report.findByUsernameANDGoal2");
        query.setParameter("username", username);
        query.setParameter("goal", goal);
        return query.getResultList();
    }
    
    // task 5a  remaining = consumed - burned - goal
    @GET
    @Path("returnTotalCalorieConsumedBurnedANDRemaining/{userid}/{createdate}")
    @Produces({MediaType.APPLICATION_JSON})
    public Object returnTotalCalorieConsumedBurnedANDRemaining(@PathParam("userid") int userid, @PathParam("createdate") String createdate) {
        TypedQuery<Object[]> query = em.createQuery("SELECT r.totalConsume,r.totalBurned, r.goal FROM Report AS r WHERE r.userid.userid = :userid AND r.createdate = :createdate", Object[].class);
        query.setParameter("userid", userid);
        query.setParameter("createdate", createdate);
        List<Object[]> list = query.getResultList( );
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        for (Object[] r: list) {
            JsonObject calorieObject = Json.createObjectBuilder().
                    add("totalConsumeCalorie", (String)r[0])
                    .add("totalBurnedCalorie", (String)r[1])
                    .add("remainingCalorie", Integer.parseInt((String)r[0])-Integer.parseInt((String)r[1])-(int)r[2]).build();
            arrayBuilder.add(calorieObject);
        }
        JsonArray jArray = arrayBuilder.build();
        return jArray;
    }
    
    // task 5b
    @GET
    @Path("returnTotalCaloriesConsumedBurnedANDSteps/{userid}/{startdate}/{enddate}")
    @Produces({MediaType.APPLICATION_JSON})
    public Object returnTotalCaloriesConsumedBurnedANDSteps(@PathParam("userid") int userid, @PathParam("startdate") String startdate, @PathParam("enddate") String enddate) {
        TypedQuery<Object[]> query = em.createQuery("SELECT r.totalConsume,r.totalBurned, r.totalSteps FROM Report AS r WHERE r.userid.userid = :userid AND r.createdate BETWEEN :startdate AND :enddate", Object[].class);
        query.setParameter("userid", userid);
        query.setParameter("startdate", startdate);
        query.setParameter("enddate", enddate);
        List<Object[]> list1 = query.getResultList( );
        int calorieTotalConsumed = 0;
        int caloireTotalBurned = 0;
        int totalSteps = 0;
        for (Object[] row : list1) {
            calorieTotalConsumed += Integer.parseInt((String)row[0]);
            caloireTotalBurned += Integer.parseInt((String)row[1]);
            totalSteps += Integer.parseInt((String)row[2]);
        }
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        
        JsonObject calorieObject = Json.createObjectBuilder().
                add("totalConsumeCalorie", calorieTotalConsumed)
                .add("totalBurnedCalorie", caloireTotalBurned)
                .add("totalStepsTaken", totalSteps).build();
        arrayBuilder.add(calorieObject);
        JsonArray jArray = arrayBuilder.build();
        return jArray;
    }

    
    
    // add on reportfacade   
    @GET
    @Path("findByCreatedate/{createdate}")
        @Produces({"application/json"})
        public List<Report> findByCreatedate (@PathParam("createdate") String createdate){
            Query query = em.createNamedQuery("Report.findByCreatedate");
            query.setParameter("createdate", createdate);
            return query.getResultList();
        }
        
    @GET
    @Path("findByTotalConsume/{totalConsume}")
        @Produces({"application/json"})
        public List<Report> findByTotalConsume (@PathParam("totalConsume") String totalConsume){
            Query query = em.createNamedQuery("Report.findByTotalConsume");
            query.setParameter("totalConsume", totalConsume);
            return query.getResultList();
        }
        
    @GET
    @Path("findByTotalBurned/{totalBurned}")
        @Produces({"application/json"})
        public List<Report> findByTotalBurned (@PathParam("totalBurned") String totalBurned){
            Query query = em.createNamedQuery("Report.findByTotalBurned");
            query.setParameter("totalBurned", totalBurned);
            return query.getResultList();
        }
        
    @GET
    @Path("findByTotalSteps/{totalSteps}")
        @Produces({"application/json"})
        public List<Report> findByTotalSteps (@PathParam("totalSteps") String totalSteps){
            Query query = em.createNamedQuery("Report.findByTotalSteps");
            query.setParameter("totalSteps", totalSteps);
            return query.getResultList();
        }
        
    @GET
    @Path("findByGoal/{goal}")
        @Produces({"application/json"})
        public List<Report> findByGoal (@PathParam("goal") int goal){
            Query query = em.createNamedQuery("Report.findByGoal");
            query.setParameter("goal", goal);
            return query.getResultList();
        }
        
    
    
    
    
    

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Report find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Report> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Report> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
