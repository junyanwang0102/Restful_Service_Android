/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fitness;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author andrew
 */
@Entity
@Table(name = "CONSUMPTION")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Consumption.findAll", query = "SELECT c FROM Consumption c")
    , @NamedQuery(name = "Consumption.findByConsumeid", query = "SELECT c FROM Consumption c WHERE c.consumeid = :consumeid")
    , @NamedQuery(name = "Consumption.findByConsumedate", query = "SELECT c FROM Consumption c WHERE c.consumedate = :consumedate")
    , @NamedQuery(name = "Consumption.findByQuantity", query = "SELECT c FROM Consumption c WHERE c.quantity = :quantity")})
public class Consumption implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "CONSUMEID")
    private Integer consumeid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "CONSUMEDATE")
    private String consumedate;
    @Basic(optional = false)
    @NotNull
    @Column(name = "QUANTITY")
    private int quantity;
    @JoinColumn(name = "FOODID", referencedColumnName = "FOODID")
    @ManyToOne(optional = false)
    private Food foodid;
    @JoinColumn(name = "USERID", referencedColumnName = "USERID")
    @ManyToOne(optional = false)
    private Users userid;

    public Consumption() {
    }

    public Consumption(Integer consumeid) {
        this.consumeid = consumeid;
    }

    public Consumption(Integer consumeid, String consumedate, int quantity) {
        this.consumeid = consumeid;
        this.consumedate = consumedate;
        this.quantity = quantity;
    }

    public Integer getConsumeid() {
        return consumeid;
    }

    public void setConsumeid(Integer consumeid) {
        this.consumeid = consumeid;
    }

    public String getConsumedate() {
        return consumedate;
    }

    public void setConsumedate(String consumedate) {
        this.consumedate = consumedate;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Food getFoodid() {
        return foodid;
    }

    public void setFoodid(Food foodid) {
        this.foodid = foodid;
    }

    public Users getUserid() {
        return userid;
    }

    public void setUserid(Users userid) {
        this.userid = userid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (consumeid != null ? consumeid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Consumption)) {
            return false;
        }
        Consumption other = (Consumption) object;
        if ((this.consumeid == null && other.consumeid != null) || (this.consumeid != null && !this.consumeid.equals(other.consumeid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "fitness.Consumption[ consumeid=" + consumeid + " ]";
    }
    
}
